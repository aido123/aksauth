Connect to your AKS RBAC Cluster Non Interactively


